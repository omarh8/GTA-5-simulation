
# Self-Driving Car Research: 
* I Created A Virtual Self Driving Car With Deep Q-Networks: 
	* https://towardsdatascience.com/i-created-a-virtual-self-driving-car-with-deep-q-networks-7f87c0aad7c8
* Training Self Driving Cars using Reinforcement Learning:
    * https://towardsdatascience.com/reinforcement-learning-towards-general-ai-1bd68256c72d
* Deep Reinforcement Learning for General Video Game AI: 
    * https://arxiv.org/pdf/1806.02448.pdf 
* Simple Reinforcement Learning with TensorFlow Part 0: Q-Learning with Tables and Neural Networks:
    * https://medium.com/emergent-future/simple-reinforcement-learning-with-tensorflow-part-0-q-learning-with-tables-and-neural-networks-d195264329d0 
* Open AI Universe:
    * https://blog.openai.com/universe/

# Python References: 
* Capture video data from screen in Python: https://stackoverflow.com/questions/35097837/capture-video-data-from-screen-in-python


