
# Import function to capture screen
import MssScreenCapture

def runLoop():
    print("Inside loop")

# Run program
if __name__ == '__main__':
    MssScreenCapture.screen_capture()
    
    
